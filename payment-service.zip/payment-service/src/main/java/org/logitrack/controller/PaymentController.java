package org.logitrack.controller;

import org.logitrack.services.PaymentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.logitrack.dto.request.PaymentRequest;
import org.logitrack.dto.response.ApiResponse;
import org.logitrack.exceptions.CommonApplicationException;
import org.logitrack.utils.Utils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/payment-gateway")
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping(path = "/initialize")
    public ResponseEntity<ApiResponse> initiatePayment(@RequestBody PaymentRequest request, @RequestHeader("Authorization") String authorizationHeader) throws CommonApplicationException {
        var userDetails= Utils.validateTokenAndReturnDetail(authorizationHeader.substring(7));
        log.info("Verify payment ", userDetails.get(" name"));
        return ResponseEntity.ok(paymentService.initializePayment(request, (String)userDetails.get("email")));
    }

    @GetMapping(path = "/verify")
    public ResponseEntity<ApiResponse> verifyPayment(@RequestBody PaymentRequest request, @RequestHeader("Authorization") String authorizationHeader) throws CommonApplicationException {
        var userDetails= Utils.validateTokenAndReturnDetail(authorizationHeader.substring(7));
        log.info("Verify payment ", userDetails.get(" name"));
        return ResponseEntity.ok(paymentService.verifyPayment(request, (String)userDetails.get("email")));
    }
}
