package org.logitrack.services.implementation;

import com.google.gson.Gson;
import org.logitrack.services.PaymentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.logitrack.dto.request.PaymentRequest;
import org.logitrack.dto.response.ApiResponse;
import org.logitrack.dto.response.PaymentResponse;
import org.logitrack.entities.Transactions;
import org.logitrack.entities.User;
import org.logitrack.enums.Status;
import org.logitrack.utils.PayStackApiConstants;
import org.logitrack.repository.TransactionsRepo;
import org.logitrack.repository.UserRepository;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Collections;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final RestTemplate restTemplate;
    private final UserRepository userRepository;
    private final TransactionsRepo transactionRepository;


//    @Value("${PayStackTestSecretKey}")
    private String payStackKey = "sk_test_9f17bd1326b598a21937849f6c7c68ca6397b609";

    @Override
    public ApiResponse initializePayment(PaymentRequest request, String email) {

        log.info("check if user exists");
        Optional<User> user = userRepository.findByEmail(email);
        if (user.isEmpty()) {
            return new ApiResponse("00", "User not found", HttpStatus.NOT_FOUND);
        }
        log.info(String.valueOf(user));


        try
        {
            request.setEmail(email);
            Gson gson = new Gson();
            String data = gson.toJson(request);
            log.info(data);

            HttpHeaders header = new HttpHeaders();
            header.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
            header.add("Content-Type", "application/json");
            header.add("Authorization", "Bearer " + payStackKey);

        HttpEntity<String> httpRequest = new HttpEntity<>(data, header);

        ResponseEntity<PaymentResponse> responseEntity = restTemplate.postForEntity(
                (PayStackApiConstants.PAYSTACK_INITIALIZE_PAY), httpRequest, PaymentResponse.class);

        log.info("Resp-entity: "+ responseEntity.getBody());

//        String jsonString = responseEntity.getBody();
//        ObjectMapper objectMapper = new ObjectMapper();
//        PaymentResponse paymentResponse = objectMapper.readValue(jsonString, PaymentResponse.class);

        PaymentResponse paymentResponse = responseEntity.getBody();


        Transactions newTransactions = new Transactions();

//        newTransactions.setReference(paymentResponse.getData().getClass().descriptorString());
        newTransactions.setId(user.get().getId());
        newTransactions.setAmount( request.getAmount());
        newTransactions.setCreatedOn(LocalDate.now());
        newTransactions.setCreatedAt(LocalTime.now());
        newTransactions.setTransactionStatus(Status.IN_PROGRESS);

        transactionRepository.save(newTransactions);

        return ApiResponse.builder()
                .code("00")
                .message(paymentResponse.getMessage() + " 980")
                .data(paymentResponse.getData())
                .build();
    }  catch (
    HttpClientErrorException e) {
        if (e.getStatusCode() == HttpStatus.UNAUTHORIZED) {
            log.info(e.getMessage());
            log.error("Unauthorized request. Please check your credentials.");
            return new ApiResponse<>(e.getMessage());
        } else {
            log.error("HTTP error: " + e.getStatusCode());
            log.error("Response body: " + e.getResponseBodyAsString());
            return new ApiResponse<>(e.getResponseBodyAsString());
        }
    } catch (Exception e) {
        log.error("An error occurred: " + e.getMessage());
        return new ApiResponse<>(e.getMessage());
        }
    }

    @Override
    public ApiResponse verifyPayment(PaymentRequest request, String email) {

        HttpHeaders header = new HttpHeaders();
        header.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        header.add("Content-Type", "application/json");
        header.add("Authorization", "Bearer " + payStackKey);

        try{
        HttpEntity<String> httpEntity = new HttpEntity<>(header);

        ResponseEntity<PaymentResponse> responseEntity = restTemplate.exchange(
                PayStackApiConstants.PAYSTACK_VERIFY + request.getReference(),
                HttpMethod.GET, httpEntity, PaymentResponse.class);

        PaymentResponse paymentResponse = responseEntity.getBody();

        return ApiResponse.builder()
                .code("00")
                .message(paymentResponse.getMessage() + " 1000")
                .data(paymentResponse.getData())
                .build();
    }catch (
                HttpClientErrorException e) {
            if (e.getStatusCode() == HttpStatus.UNAUTHORIZED) {
                log.info(e.getMessage());
                log.error("Unauthorized request. Please check your credentials.");
                return new ApiResponse<>(e.getMessage());
            } else {
                log.error("HTTP error: " + e.getStatusCode());
                log.error("Response body: " + e.getResponseBodyAsString());
                return new ApiResponse<>(e.getResponseBodyAsString());
            }
        } catch (Exception e) {
            log.error("An error occurred: " + e.getMessage());
            return new ApiResponse<>(e.getMessage());
        }
    }

}
